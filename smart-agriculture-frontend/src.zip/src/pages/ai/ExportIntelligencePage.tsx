import { useState } from 'react';
import TempAINav from '../../components/layout/TempAINav';
import { useTranslation } from 'react-i18next';
import { predictExportApi } from '../../api/exportApi';
import Card from '../../components/common/Card';
import Button from '../../components/common/Button';
import Loader from '../../components/common/Loader';

const markets = [
  { key: 'eu', label: 'الاتحاد الأوروبي 🇪🇺' },
  { key: 'gulf', label: 'الخليج 🇸🇦' },
  { key: 'local', label: 'السوق المحلي 🏠' },
];

const inputStyle: React.CSSProperties = {
  background: 'var(--bg-input)',
  border: '1px solid var(--border-input)',
  borderRadius: '0.5rem',
  padding: '0.55rem 0.875rem',
  fontSize: '0.875rem',
  color: 'var(--text-primary)',
  outline: 'none',
  fontFamily: 'inherit',
  width: '100%',
  boxSizing: 'border-box',
  transition: 'border-color 0.2s',
};

const labelStyle: React.CSSProperties = {
  fontSize: '0.875rem',
  fontWeight: 500,
  color: 'var(--text-secondary)',
};

// Grade-based starting points for the quality sliders. These are only a
// convenient starting point — every value is fully editable, and it's the
// actual slider values (not the grade) that get sent to the model.
const GRADE_PRESETS: Record<string, Record<string, number>> = {
  A: { moisture: 12, defect_rate: 3, pesticide_level: 1.5, sugar_content: 14, size_uniformity: 90, color_score: 9, shelf_life_days: 21, temperature_storage: 6, ph_level: 6.5 },
  B: { moisture: 16, defect_rate: 10, pesticide_level: 3, sugar_content: 11, size_uniformity: 75, color_score: 7, shelf_life_days: 14, temperature_storage: 10, ph_level: 6.2 },
  C: { moisture: 20, defect_rate: 20, pesticide_level: 8, sugar_content: 9, size_uniformity: 52, color_score: 3, shelf_life_days: 5, temperature_storage: 15, ph_level: 5.5 },
};

const qualitySliders = [
  { key: 'moisture', label: 'نسبة الرطوبة (%)', min: 0, max: 40, step: 0.5 },
  { key: 'defect_rate', label: 'نسبة التلف (%)', min: 0, max: 50, step: 0.5 },
  { key: 'pesticide_level', label: 'مستوى المبيدات (ppm)', min: 0, max: 15, step: 0.1 },
  { key: 'sugar_content', label: 'نسبة السكر (%)', min: 0, max: 25, step: 0.5 },
  { key: 'size_uniformity', label: 'تجانس الحجم (%)', min: 0, max: 100, step: 1 },
  { key: 'color_score', label: 'درجة اللون (0-10)', min: 0, max: 10, step: 0.1 },
  { key: 'shelf_life_days', label: 'مدة الصلاحية (يوم)', min: 0, max: 40, step: 1 },
  { key: 'temperature_storage', label: 'حرارة التخزين (°م)', min: -5, max: 30, step: 0.5 },
  { key: 'ph_level', label: 'مستوى الحموضة (pH)', min: 0, max: 14, step: 0.1 },
] as const;

const ExportIntelligencePage = () => {
  const { t } = useTranslation();
  const [form, setForm] = useState({
    crop_type: '',
    quality_grade: 'A',
    weight: '',
    region: '',
  });
  const [quality, setQuality] = useState<Record<string, number>>({ ...GRADE_PRESETS.A });
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
    // Re-seed the quality sliders to the new grade's typical values so the
    // form stays sensible, but the user can still override any of them.
    if (name === 'quality_grade' && GRADE_PRESETS[value]) {
      setQuality({ ...GRADE_PRESETS[value] });
    }
  };

  const handleQualityChange = (key: string, value: number) => {
    setQuality(prev => ({ ...prev, [key]: value }));
  };

  const handleAnalyze = async () => {
    if (!form.crop_type || !form.weight || !form.region) {
      setError('من فضلك ادخل كل البيانات');
      return;
    }
    try {
      setLoading(true);
      setError('');
      const data = await predictExportApi({
        crop_type: form.crop_type,
        quality_grade: form.quality_grade,
        weight: Number(form.weight),
        region: form.region,
        ...quality,
      });
      setResult(data);
    } catch (err: any) {
      setError('حدث خطأ أثناء التحليل، حاول تاني');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <TempAINav />
      <div style={{ maxWidth: '900px', margin: '0 auto', padding: '2rem 1.5rem' }}>
        {/* Header */}
        <div style={{ marginBottom: '2rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '0.5rem' }}>
            <div style={{
              width: 40, height: 40, borderRadius: 10,
              background: 'var(--teal-glow)', border: '1px solid rgba(6,182,212,0.2)',
              display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.2rem',
            }}>🚢</div>
            <h1 style={{ fontSize: '1.5rem', fontWeight: 700, color: 'var(--text-primary)' }}>
              {t('ai.export_title')}
            </h1>
          </div>
          <p style={{ color: 'var(--text-secondary)', fontSize: '0.875rem' }}>
            ادخل بيانات المحصول وهنديك توصيات التصدير لكل سوق
          </p>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '1.5rem' }}>
          {/* Form Section */}
          <Card>
            <h2 style={{ fontWeight: 700, color: 'var(--text-primary)', marginBottom: '1rem', fontSize: '0.95rem' }}>
              بيانات المحصول
            </h2>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              {/* Crop Type */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.35rem' }}>
                <label style={labelStyle}>نوع المحصول <span style={{ color: 'var(--rose)' }}>*</span></label>
                <select
                  name="crop_type"
                  value={form.crop_type}
                  onChange={handleChange}
                  style={{ ...inputStyle, cursor: 'pointer' }}
                >
                  <option value="">اختر نوع المحصول</option>
                  <option value="tomato">طماطم</option>
                  <option value="orange">برتقال</option>
                  <option value="strawberry">فراولة</option>
                  <option value="potato">بطاطس</option>
                  <option value="pepper">فلفل</option>
                  <option value="grape">عنب</option>
                  <option value="apple">تفاح</option>
                  <option value="banana">موز</option>
                  <option value="mango">مانجو</option>
                  <option value="onion">بصل</option>
                </select>
              </div>
              {/* Quality Grade */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.35rem' }}>
                <label style={labelStyle}>درجة الجودة <span style={{ color: 'var(--rose)' }}>*</span></label>
                <select
                  name="quality_grade"
                  value={form.quality_grade}
                  onChange={handleChange}
                  style={{ ...inputStyle, cursor: 'pointer' }}
                >
                  <option value="A">Grade A — ممتاز</option>
                  <option value="B">Grade B — جيد</option>
                  <option value="C">Grade C — مقبول</option>
                </select>
              </div>
              {/* Weight */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.35rem' }}>
                <label style={labelStyle}>الوزن (كجم) <span style={{ color: 'var(--rose)' }}>*</span></label>
                <input
                  name="weight"
                  type="number"
                  value={form.weight}
                  onChange={handleChange}
                  placeholder="مثال: 1000"
                  style={inputStyle}
                  onFocus={e => { e.currentTarget.style.borderColor = 'var(--emerald)'; e.currentTarget.style.boxShadow = '0 0 0 3px var(--emerald-glow)'; }}
                  onBlur={e => { e.currentTarget.style.borderColor = 'var(--border-input)'; e.currentTarget.style.boxShadow = 'none'; }}
                />
              </div>
              {/* Region */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.35rem' }}>
                <label style={labelStyle}>منطقة الزراعة <span style={{ color: 'var(--rose)' }}>*</span></label>
                <select
                  name="region"
                  value={form.region}
                  onChange={handleChange}
                  style={{ ...inputStyle, cursor: 'pointer' }}
                >
                  <option value="">اختر المنطقة</option>
                  <option value="Nile_Delta">دلتا النيل</option>
                  <option value="Upper_Egypt">الصعيد</option>
                  <option value="Alexandria">الإسكندرية</option>
                  <option value="Sinai">سيناء</option>
                  <option value="Fayoum">الفيوم</option>
                  <option value="Beheira">البحيرة</option>
                  <option value="Minya">المنيا</option>
                  <option value="Aswan">أسوان</option>
                </select>
              </div>

              {/* Advanced quality features — these are what actually drive the prediction */}
              <div style={{ borderTop: '1px solid var(--border-input)', paddingTop: '0.75rem', marginTop: '0.25rem' }}>
                <button
                  type="button"
                  onClick={() => setShowAdvanced(v => !v)}
                  style={{
                    background: 'transparent', border: 'none', cursor: 'pointer',
                    color: 'var(--emerald)', fontSize: '0.85rem', fontWeight: 600,
                    padding: 0, display: 'flex', alignItems: 'center', gap: '0.35rem',
                  }}
                >
                  {showAdvanced ? '▲' : '▼'} مقاييس الجودة التفصيلية (تتحكم في النتيجة فعليًا)
                </button>
                {showAdvanced && (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.85rem', marginTop: '0.85rem' }}>
                    {qualitySliders.map(s => (
                      <div key={s.key} style={{ display: 'flex', flexDirection: 'column', gap: '0.25rem' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                          <label style={{ ...labelStyle, fontSize: '0.8rem' }}>{s.label}</label>
                          <span style={{ fontSize: '0.8rem', color: 'var(--text-primary)', fontWeight: 600 }}>
                            {quality[s.key]}
                          </span>
                        </div>
                        <input
                          type="range"
                          min={s.min}
                          max={s.max}
                          step={s.step}
                          value={quality[s.key]}
                          onChange={e => handleQualityChange(s.key, Number(e.target.value))}
                          style={{ width: '100%' }}
                        />
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {error && (
                <p style={{ color: 'var(--rose)', fontSize: '0.875rem', textAlign: 'center' }}>{error}</p>
              )}
              <Button label={t('ai.analyze_btn')} onClick={handleAnalyze} loading={loading} fullWidth />
            </div>
          </Card>
          {/* Result Section */}
          <Card>
            <h2 style={{ fontWeight: 700, color: 'var(--text-primary)', marginBottom: '1rem', fontSize: '0.95rem' }}>
              {t('ai.result')}
            </h2>
            {loading && <Loader text="جاري تحليل بيانات التصدير..." />}
            {!loading && !result && (
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: 180, color: 'var(--text-muted)' }}>
                <span style={{ fontSize: '3rem' }}>🌍</span>
                <p style={{ fontSize: '0.875rem', marginTop: '0.5rem' }}>توصيات التصدير هتظهر هنا</p>
              </div>
            )}
            {!loading && result && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.875rem' }}>
                {markets.map((market) => {
                  const marketResult = result[market.key];
                  const eligible = marketResult?.eligible;
                  return (
                    <div
                      key={market.key}
                      style={{
                        border: `1px solid ${eligible ? 'var(--border-chip)' : 'rgba(244,63,94,0.2)'}`,
                        borderRadius: '0.75rem',
                        padding: '0.875rem 1rem',
                        background: eligible ? 'var(--emerald-glow)' : 'rgba(244,63,94,0.06)',
                      }}
                    >
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.35rem' }}>
                        <p style={{ fontWeight: 700, color: 'var(--text-primary)', fontSize: '0.9rem' }}>{market.label}</p>
                        <span style={{
                          fontSize: '0.75rem', fontWeight: 700,
                          padding: '0.2rem 0.6rem', borderRadius: '999px',
                          background: eligible ? 'rgba(0,201,167,0.15)' : 'rgba(244,63,94,0.12)',
                          color: eligible ? 'var(--emerald)' : 'var(--rose)',
                        }}>
                          {eligible ? '✅ مؤهل' : '❌ غير مؤهل'}
                        </span>
                      </div>
                      {marketResult?.reason && (
                        <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>{marketResult.reason}</p>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </Card>
        </div>
      </div>
    </>
  );
};

export default ExportIntelligencePage;
